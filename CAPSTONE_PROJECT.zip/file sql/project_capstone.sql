create database if not exists capstone_project;
USE capstone_project;

create table area 
(cod_area varchar(255) primary key,
desc_area varchar (255)
);
select*from area;

create table region
(cod_region varchar(255) primary key, 
desc_region varchar(255)
);
select*from region;

create table T_gradi(
id_grado varchar(255) primary key,
desc_grado varchar(255)
);
select*from T_GRADI;

create table if not exists angrafica_venditori(
livello int,
ORDINE int,
id_venditore varchar(255) primary key,
Nome_venditore varchar(255),
Grado_Ag varchar(255),
reg varchar(255),
Area varchar(255),
Superiore_Diretto varchar(255),
constraint fk_area foreign key (area) references area(cod_area),
constraint fk_region foreign key (reg) references region(cod_region),
constraint FK_gradi foreign key (Grado_Ag) references T_gradi(id_grado)
);
SELECT*FROM angrafica_venditori;

create table KPI( 
periodo varchar(255),
id_venditore varchar(255),
Data_ date,
contatti int,
TOTALE_VENDITE_NETTO DECIMAL (10,2),
TOTALE_VENDITE_LORDO DECIMAL(10,2),
ORDINI INT,
ORDINI_PREMIUM int,
constraint FK_id_venditore 
foreign key (id_venditore) references angrafica_venditori(id_venditore )
);
SELECT*FROM KPI;

CREATE TABLE T_ORDINI (
id_venditore varchar(255),
id_materiale varchar(255),
id_cliente varchar(255),
data_ date,
qtà int,
anticipo decimal (10,2),
caparra decimal (10,2),
netto decimal (10,2),
importo_lordo decimal(10,2),
valore_IVA decimal(10,2),
constraint FK_Venditore_ordini foreign key (id_venditore) references angrafica_venditori(id_venditore),
constraint FK_Clienti foreign key (id_cliente) references T_clienti(id_cliente),
constraint FK_Materiale foreign key (id_materiale) references T_materiali(id_materiale)
);
SELECT*FROM T_ORDINI;
alter table T_ORDINI ADD column ID_ORDINE varchar(255) primary key ;
alter table T_ORDINI drop primary key;
alter table T_ordini add column rating int ;
TRUNCATE TABLE T_ORDINI;

create table T_clienti(
id_cliente varchar(255) primary key,
cliente_nome varchar(255),
cliente_città varchar(255),
cliente_provincia varchar (255)
);
SELECT*FROM T_CLIENTI ;

create table T_materiali (
tipologia_prodotti VARCHAR (255),
id_materiale varchar(255)primary key,
desc_materiale text
);
SELECT*FROM T_MATERIALI;


DELIMITER $$

CREATE PROCEDURE RicostruisciAnagraficaGerarchica()
BEGIN

    CREATE TEMPORARY TABLE temp_consulenti2 AS
    SELECT c1.id_venditore AS id_venditore, c2.id_venditore AS Superiore_Diretto
    FROM angrafica_venditori c1
    JOIN angrafica_venditori c2 ON c2.livello = 1
    AND c2.Area = c1.Area
    AND c2.reg = c1.reg
    AND c2.ORDINE < c1.ORDINE
    WHERE c1.livello = 2
    ORDER BY c2.ORDINE DESC;

    UPDATE angrafica_venditori c1
    JOIN temp_consulenti2 t ON c1.id_venditore = t.id_venditore
    SET c1.Superiore_Diretto = t.Superiore_Diretto;

    DROP TEMPORARY TABLE temp_consulenti2;

    CREATE TEMPORARY TABLE temp_consulenti3 AS
    SELECT c1.id_venditore AS id_venditore, c2.id_venditore AS Superiore_Diretto
    FROM angrafica_venditori c1
    JOIN angrafica_venditori c2 ON c2.livello = 2
    AND c2.Area = c1.Area
    AND c2.reg = c1.reg
    AND c2.ORDINE < c1.ORDINE
    WHERE c1.livello = 3
    ORDER BY c2.ORDINE DESC;

    UPDATE angrafica_venditori c1
    JOIN temp_consulenti3 t ON c1.id_venditore = t.id_venditore
    SET c1.Superiore_Diretto = t.Superiore_Diretto;

    DROP TEMPORARY TABLE temp_consulenti3;

    CREATE TEMPORARY TABLE temp_consulenti4 AS
    SELECT c1.id_venditore AS id_venditore, c2.id_venditore AS Superiore_Diretto
    FROM angrafica_venditori c1
    JOIN angrafica_venditori c2 ON c2.livello = 3
    AND c2.Area = c1.Area
    AND c2.reg = c1.reg
    AND c2.ORDINE < c1.ORDINE
    WHERE c1.livello = 4
    ORDER BY c2.ORDINE DESC;

    UPDATE angrafica_venditori c1
    JOIN temp_consulenti4 t ON c1.id_venditore = t.id_venditore
    SET c1.Superiore_Diretto = t.Superiore_Diretto;

    DROP TEMPORARY TABLE temp_consulenti4;

    CREATE TEMPORARY TABLE temp_consulenti5 AS
    SELECT c1.id_venditore AS id_venditore, c2.id_venditore AS Superiore_Diretto
    FROM angrafica_venditori c1
    JOIN angrafica_venditori c2 ON c2.livello = 4
    AND c2.Area = c1.Area
    AND c2.reg = c1.reg
    AND c2.ORDINE < c1.ORDINE
    WHERE c1.livello = 5
    ORDER BY c2.ORDINE DESC;

    UPDATE angrafica_venditori c1
    JOIN temp_consulenti5 t ON c1.id_venditore = t.id_venditore
    SET c1.Superiore_Diretto = t.Superiore_Diretto;

    DROP TEMPORARY TABLE temp_consulenti5;

  
    CREATE TEMPORARY TABLE temp_consulenti6 AS
    SELECT c1.id_venditore AS id_venditore, c2.id_venditore AS Superiore_Diretto
    FROM angrafica_venditori c1
    JOIN angrafica_venditori c2 ON c2.livello = 5
    AND c2.Area = c1.Area
    AND c2.reg = c1.reg
    AND c2.ORDINE < c1.ORDINE
    WHERE c1.livello = 6
    ORDER BY c2.ORDINE DESC;

    UPDATE angrafica_venditori c1
    JOIN temp_consulenti6 t ON c1.id_venditore = t.id_venditore
    SET c1.Superiore_Diretto = t.Superiore_Diretto;

    DROP TEMPORARY TABLE temp_consulenti6;

    
    CREATE TEMPORARY TABLE temp_consulenti7 AS
    SELECT c1.id_venditore AS id_venditore, c2.id_venditore AS Superiore_Diretto
    FROM angrafica_venditori c1
    JOIN angrafica_venditori c2 ON c2.livello = 6
    AND c2.Area = c1.Area
    AND c2.reg = c1.reg
    AND c2.ORDINE < c1.ORDINE
    WHERE c1.livello = 7
    ORDER BY c2.ORDINE DESC;

    UPDATE angrafica_venditori c1
    JOIN temp_consulenti7 t ON c1.id_venditore = t.id_venditore
    SET c1.Superiore_Diretto = t.Superiore_Diretto;

    DROP TEMPORARY TABLE temp_consulenti7;

    DROP TABLE IF EXISTS anagrafica_gerarchia_ricostruita;
    CREATE TABLE anagrafica_gerarchia_ricostruita AS 
    WITH RECURSIVE catena_gerarchica AS (
        SELECT
            c.id_venditore,
            c.Nome_venditore,
            CAST(c.id_venditore AS CHAR) AS Catena,
            1 AS Profondita
        FROM angrafica_venditori c
        WHERE c.Superiore_Diretto IS NULL

        UNION ALL

        SELECT
            c.id_venditore,
            c.Nome_venditore,
            CONCAT(g.Catena, ' --> ', c.id_venditore),
            g.Profondita + 1
        FROM angrafica_venditori c
        JOIN catena_gerarchica g ON c.Superiore_Diretto = g.id_venditore
    )
    SELECT *
    FROM catena_gerarchica
    ORDER BY Profondita, Catena;
    
    ALTER TABLE anagrafica_gerarchia_ricostruita
    ADD CONSTRAINT FK_ID_venditore_GER
    FOREIGN KEY (id_venditore) REFERENCES angrafica_venditori(id_venditore);
    
END$$

DELIMITER ;

CALL RicostruisciAnagraficaGerarchica;

select*from anagrafica_gerarchia_ricostruita;


DROP TEMPORARY TABLE IF EXISTS tabella_prova;
CREATE TEMPORARY TABLE tabella_prova AS 
SELECT 
    t2.livello, 
    t2.ordine,
    t1.id_venditore AS ID,
    t1.nome_venditore AS NOME,
    t4.desc_area,
    t3.desc_region, 
    t1.catena, 
    t1.profondita,
    SUM(t5.totale_vendite_netto) AS vendite
FROM anagrafica_gerarchia_ricostruita AS t1
LEFT JOIN angrafica_venditori AS t2 ON t2.id_venditore = t1.id_venditore
LEFT JOIN region AS t3 ON t3.cod_region = t2.reg
LEFT JOIN area AS t4 ON t4.cod_area = t2.area
LEFT JOIN kpi AS t5 ON t5.id_venditore = t1.id_venditore
GROUP BY 
    t2.livello, 
    t2.ordine, 
    t1.id_venditore, 
    t1.nome_venditore, 
    t4.desc_area, 
    t3.desc_region, 
    t1.catena, 
    t1.profondita;
ALTER TABLE tabella_prova
ADD COLUMN catena1 VARCHAR(255),
ADD COLUMN catena2 VARCHAR(255),
ADD COLUMN catena3 VARCHAR(255),
ADD COLUMN catena4 VARCHAR(255),
ADD COLUMN catena5 VARCHAR(255);
UPDATE tabella_prova
SET 
    catena1 = SUBSTRING_INDEX(catena, '-->', 1),
    catena2 = IF(LENGTH(catena) - LENGTH(REPLACE(catena, '-->', '')) >= 1, 
                 SUBSTRING_INDEX(SUBSTRING_INDEX(catena, '-->', 2), '-->', -1), 
                 NULL),
    catena3 = IF(LENGTH(catena) - LENGTH(REPLACE(catena, '-->', '')) >= 2, 
                 SUBSTRING_INDEX(SUBSTRING_INDEX(catena, '-->', 3), '-->', -1), 
                 NULL),
    catena4 = IF(LENGTH(catena) - LENGTH(REPLACE(catena, '-->', '')) >= 3, 
                 SUBSTRING_INDEX(SUBSTRING_INDEX(catena, '-->', 4), '-->', -1), 
                 NULL),
    catena5 = IF(LENGTH(catena) - LENGTH(REPLACE(catena, '-->', '')) >= 4, 
                 SUBSTRING_INDEX(SUBSTRING_INDEX(catena, '-->', 5), '-->', -1), 
                 NULL);
UPDATE tabella_prova
SET vendite = COALESCE(vendite, 0);
SELECT * FROM tabella_prova;


SET SQL_SAFE_UPDATES = 1; 
drop temporary table tabbella_prova ;